<?php

class Feature_model extends CI_Model{

	function __construct(){
		$this->load->database();
	}
	
	
	
	
}