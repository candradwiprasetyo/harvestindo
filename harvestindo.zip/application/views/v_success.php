<html>
<head>
 <title>Tutorial Captcha by blog.microtrafh.com</title>
</head>
<body>
 Hay <?php echo $nama;?>, kamu berhasil melakukan captcha dengan captcha kode <?php echo $captcha;?> 
</body>
</html>