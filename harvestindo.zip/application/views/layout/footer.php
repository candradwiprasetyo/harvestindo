
<div class="bluebar">

</div>
    

<div class="footer_new">
    <div class="container">
        <div class="row">
            
                <div class="col-md-2">
                    <div class="form-group">
                         <img src="<?= base_url()?>assets/images/footerbig.png" class="respimg">
                    </div>
                </div>
            
                <div class="col-md-2">
                    <div class="form-group">
                        <div class="footermenu">
                            <ul>
                                    <li class="fmhead"><a href="#">What is Bitcoin?</a></li>
                                    <li class="fmhead"><a href="#">What is Mining?</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            
                <div class="col-md-2">
                    <div class="form-group">
                         <div class="footermenu">
                        <ul>
                                <li class="fmhead"><a href="#">What is Hashfield?</a></li>
                                <li><a href="#">Our Company</a></li>
                                <li><a href="#">Our Data Center</a></li>
                                <li><a href="#">Features</a></li>
                        </ul>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-2">
                    <div class="form-group">
                         <div class="footermenu">
                                <ul>
                                        <li class="fmhead"><a href="#">My Account</a></li>
                                        <li><a href="#">Contracts</a></li>
                                        <li><a href="#">Edit Account</a></li>
                                        <li><a href="#">Edit Payout Address</a></li>
                                </ul>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-2">
                    <div class="form-group">
                          <div class="footermenu">
                                    <ul>
                                            <li class="fmhead"><a href="#">Contact Us</a></li>
                                            <li class="fmhead"><a href="#">Terms of Use</a></li>
                                            <li class="fmhead"><a href="#">Privacy Policy</a></li>
                                    </ul>
                            </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-5">
                        <div class="form-group">
                                <div class="footertext">
                                &copy; 2016 HASHFIELD. All Rights Reserved. Miningcloud by <img src="<?= base_url() ?>assets/images/footersmall.png">. Developed by ELEVATE&reg;
                                </div>
                        </div>
                    </div>
                
                    <div class="col-md-5">
                        <div class="form-group" style="text-align:right;">
                       <p style="font-size:0.9em;"><strong>Hashfield.io&reg;</strong><br>a company by PT. Harvestindo Global Persada<br>Intiland Tower - Jl. Panglima Sudirman 101-103<br>Surabaya - Indonesia 60274</p>
                        </div>
                    </div>
                </div>
                
         </div>
    </div>
</div>

</body>
</html>
   
<script type='text/javascript' src='<?= base_url('assets/js/jquery_footer.js') ?>'></script>
<script type='text/javascript' src='<?= base_url('assets/js/functions.js?ver=20150315') ?>'></script>
<script type='text/javascript' src='<?= base_url('assets/js/jquery.touchwipe.min.js?ver=1.4.6') ?>'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var JQLBSettings = {"showTitle":"1","showCaption":"0","showNumbers":"0","fitToScreen":"0","resizeSpeed":"400","showDownload":"0","navbarOnTop":"1","marginSize":"0","slideshowSpeed":"0","prevLinkTitle":"previous image","nextLinkTitle":"next image","closeTitle":"close image gallery","image":"Image ","of":" of ","download":"Download","pause":"(pause slideshow)","play":"(play slideshow)"};
/* ]]> */
</script>
<script type='text/javascript' src='<?= base_url('assets/js/jquery.lightbox.min.js?ver=1.4.6') ?>'></script>
